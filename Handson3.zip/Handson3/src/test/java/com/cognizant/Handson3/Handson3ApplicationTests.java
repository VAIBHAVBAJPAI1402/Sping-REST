package com.cognizant.Handson3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Handson3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
