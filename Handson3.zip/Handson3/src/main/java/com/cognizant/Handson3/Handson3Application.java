package com.cognizant.Handson3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Handson3Application {

	public static void main(String[] args) {
		SpringApplication.run(Handson3Application.class, args);
	}

}
