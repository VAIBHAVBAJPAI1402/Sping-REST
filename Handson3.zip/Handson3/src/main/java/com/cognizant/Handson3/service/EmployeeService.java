package com.cognizant.Handson3.service;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

import com.cognizant.Handson3.model.Employee;

@Service
public class EmployeeService {
	
	private static ApplicationContext ctx=new ClassPathXmlApplicationContext("employee.xml");
	
	public List<Employee> getEmployeeList(){
		List<Employee> employeeList=ctx.getBean("employeeList", java.util.ArrayList.class);
		return employeeList;
	}

}
