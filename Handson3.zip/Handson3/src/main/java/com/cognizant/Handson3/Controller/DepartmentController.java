package com.cognizant.Handson3.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.Handson3.model.Department;
import com.cognizant.Handson3.service.DepartmentService;

@RestController
public class DepartmentController {
	
	@Autowired
	private DepartmentService service;
	
	@GetMapping("/departments")
	@ResponseBody
	public List<Department> showDepartmentList() {
		List<Department> list = service.getDepartmentList();
		return list;
	}
}
