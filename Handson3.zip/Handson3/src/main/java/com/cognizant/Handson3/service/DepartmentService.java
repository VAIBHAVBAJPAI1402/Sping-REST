package com.cognizant.Handson3.service;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

import com.cognizant.Handson3.model.Department;
import com.cognizant.Handson3.model.Employee;

@Service
public class DepartmentService {
	ApplicationContext ctx=new ClassPathXmlApplicationContext("employee.xml");

	public List<Department> getDepartmentList(){
		List<Department> departmentList=ctx.getBean("departmentList", java.util.ArrayList.class);
		return departmentList;
	}
}
