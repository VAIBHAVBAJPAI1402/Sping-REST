package com.cognizant.springlearn.Controller;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.springlearn.exception.CountryNotFoundException;
import com.cognizant.springlearn.model.Country;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/country")
public class CouintryController {
	
	@GetMapping("/india")
	public String getCountryIndia() {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("country.xml");
		Country india=ctx.getBean("in",Country.class);
		return india.toString();
	}
	@GetMapping("/countries")
	public List<Country> getCountries() {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("country.xml");
		List<Country> countries=ctx.getBean("countryList",java.util.ArrayList.class);
		return countries;
	}
	@GetMapping("/{code}")
	public String getCountryByCode(@PathVariable String code) throws CountryNotFoundException {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("country.xml");
		List<Country> countries=ctx.getBean("countryList",java.util.ArrayList.class);
		for(Country c:countries) {
			if(c.getCode().equalsIgnoreCase(code)) {
				return c.toString();
			}
		}
		throw new CountryNotFoundException();
	}
}
