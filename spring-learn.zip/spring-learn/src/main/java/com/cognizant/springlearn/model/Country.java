package com.cognizant.springlearn.model;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class Country {
	private String code;
	private String name;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String countryName) {
		this.name = countryName;
	}
	public Country() {
		log.info("Inside country constructor");
	}
	public Country(String code, String countryName) {
		super();
		
		this.code = code;
		this.name = countryName;
	}
	@Override
	public String toString() {
		return "Country [code=" + code + ", countryName=" + name + "]";
	}
	

}
