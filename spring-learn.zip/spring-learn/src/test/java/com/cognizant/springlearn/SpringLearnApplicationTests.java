package com.cognizant.springlearn;

import static org.junit.jupiter.api.Assertions.assertNotNull;


import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

//import org.springframework.http.HttpStatus;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;


import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.cognizant.springlearn.Controller.CouintryController;
@SpringBootTest
class SpringLearnApplicationTests {
	@Autowired
	public CouintryController controller;
	
	@Autowired
	private static MockMvc mockMvc;


	@Test
	void contextLoads() {
		assertNotNull(controller);
		
	}
	
	@Test
	void testGetCountry() throws Exception{
		ResultActions result=mockMvc.perform(get("/country/in"));
		result.andExpect(status().isOk());
		result.andExpect(jsonPath("$.code").value("IN"));
		result.andExpect(jsonPath("$.name").value("India"));
	}

}
