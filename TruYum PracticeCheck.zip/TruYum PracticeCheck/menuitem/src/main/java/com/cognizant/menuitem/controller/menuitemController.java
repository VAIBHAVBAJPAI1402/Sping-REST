package com.cognizant.menuitem.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class menuitemController {
	
	@GetMapping("/item")
	public String showItem() {
		return "new item details here!";
	}

}
