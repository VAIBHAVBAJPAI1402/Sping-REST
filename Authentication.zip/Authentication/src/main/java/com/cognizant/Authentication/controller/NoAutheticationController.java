package com.cognizant.Authentication.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/noauth")
public class NoAutheticationController {

	@GetMapping("/hi")
	public String sayHi() {
		return "Sayinh hi";
	}
}
